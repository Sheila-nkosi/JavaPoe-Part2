package javapoe;
import java.util.*;
import javax.swing.JOptionPane;
import java.io.FileWriter;

public class Message {
    private String messageID;
    private int num;
    private String recipient;
    private String message;
    private String hash;
    public static int totalMessages = 0;
    public static ArrayList<String> allMessages = new ArrayList<String>();

    public Message(String recipient, String message, int num){
        Random r = new Random();
        long id = 1000000000L + (long)(r.nextDouble() * 9000000000L);
        this.messageID = String.valueOf(id);
        this.num = num;
        this.recipient = recipient;
        this.message = message;
        this.hash = createMessageHash();
    }
    public boolean checkMessageID(){ return messageID.length() <= 10; }
    public String checkRecipientCell(){
        if(recipient != null && recipient.startsWith("+") && recipient.length() <= 13){
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code.";
        }
    }
    public String createMessageHash(){
        String firstTwo = messageID.substring(0,2);
        String[] w = message.trim().split("\\s+");
        String first = w[0].replaceAll("[^a-zA-Z0-9]","");
        String last = w[w.length-1].replaceAll("[^a-zA-Z0-9]","");
        return (firstTwo + ":" + num + ":" + first + last).toUpperCase();
    }
    public String SentMessage(){
        String[] opts = {"Send Message","Disregard Message","Store Message"};
        int c = JOptionPane.showOptionDialog(null,"Choose:","Send",0,1,null,opts,opts[0]);
        if(c==0){ totalMessages++; allMessages.add(message); return "Message successfully sent."; }
        if(c==2){ storeMessage(); return "Message successfully stored."; }
        return "Press 0 to delete the message.";
    }
    public void storeMessage(){
        try{ FileWriter f = new FileWriter("storedMessages.json", true); f.write(messageID+","+hash+","+recipient+"\n"); f.close(); }catch(Exception e){}
    }
    public String printMessages(){ return allMessages.toString(); }
    public int returnTotalMessages(){ return totalMessages; }
    public String getMessageID(){return messageID;}
    public String getMessageHash(){return hash;}
    public String getRecipient(){return recipient;}
    public String getMessage(){return message;}

    // THIS IS WHAT LETS YOU RUN MESSAGES
    public static void main(String[] args){
        JOptionPane.showMessageDialog(null,"Welcome to QuickChat.");
        String choice = JOptionPane.showInputDialog("1) Send Messages\n2) Show recently sent messages\n3) Quit");
        if(choice.equals("1")){
            int total = Integer.parseInt(JOptionPane.showInputDialog("How many messages?"));
            for(int i=0;i<total;i++){
                String rec = JOptionPane.showInputDialog("Enter recipient e.g +27718693002");
                String txt = JOptionPane.showInputDialog("Enter message");
                Message m = new Message(rec,txt,i);
                JOptionPane.showMessageDialog(null,m.checkRecipientCell());
                String result = m.SentMessage();
                JOptionPane.showMessageDialog(null,result);
                JOptionPane.showMessageDialog(null,"ID: "+m.getMessageID()+"\nHash: "+m.getMessageHash()+"\nTo: "+m.getRecipient()+"\nMsg: "+m.getMessage());
            }
            JOptionPane.showMessageDialog(null,"Total: "+totalMessages);
        } else {
            JOptionPane.showMessageDialog(null,"Coming Soon.");
        }
    }
}